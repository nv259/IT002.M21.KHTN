#include "ToaDo.h"

ToaDo::ToaDo()
{
    //ctor
}

ToaDo::~ToaDo()
{
    //dtor
}

ToaDo::ToaDo(double x = 0, double y = 0)
{
    this->x = x;
    this->y = y;
}
