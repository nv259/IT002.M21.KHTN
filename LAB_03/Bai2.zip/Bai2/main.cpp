#include "TamGiac.h"

using namespace std;

int main()
{
    TamGiac tg(0, 0, 3, 0, 0, 3);
    tg.nhap();
    tg.xuat();

    return 0;
}
