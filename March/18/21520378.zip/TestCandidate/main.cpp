#include "TestCandidate.h"
#include <iostream>
#include <string>
#include "Candidate.h"

using namespace std;

int main()
{
    TestCandidate a;
    a.nhap();

    a.xuatThiSinhTren15Diem();

    return 0;
}
