#include "Diem.h"
#include <iostream>

using namespace std;

int main()
{
    Diem a;
    a.nhap();
    a.xuat();
    a.getX();
    a.getY();
    a.setX(5);
    a.setY(10);
    a.xuat();

    return 0;
}
