#include <iostream>
#include "List.h"

using namespace std;

int main()
{
    List li;
    cin >> li;
    cout << li;

    return 0;
}
